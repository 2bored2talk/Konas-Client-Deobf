package dev.tigr.emojiapi;

public class Emoji {
   private final String name;

   public Emoji(String name) {
      this.name = name;
   }

   public String getName() {
      return this.name;
   }
}
