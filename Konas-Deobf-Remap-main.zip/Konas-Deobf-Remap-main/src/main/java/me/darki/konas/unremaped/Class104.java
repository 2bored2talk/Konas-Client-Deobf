package me.darki.konas.unremaped;

import me.darki.konas.*;
import net.minecraft.entity.player.EntityPlayer;

public class Class104 {
    public EntityPlayer Field2639;

    public Class104(EntityPlayer entityPlayer) {
        this.Field2639 = entityPlayer;
    }

    public EntityPlayer Method2308() {
        return this.Field2639;
    }
}