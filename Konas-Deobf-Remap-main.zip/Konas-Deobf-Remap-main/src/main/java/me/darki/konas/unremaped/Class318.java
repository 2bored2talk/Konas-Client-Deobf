package me.darki.konas.unremaped;

import me.darki.konas.*;
public class Class318 {
    public static int[] Field746 = new int[Class324.Method730().length];

    static {
        try {
            Class318.Field746[Class324.ROT13.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class318.Field746[Class324.PROTOCOL.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}