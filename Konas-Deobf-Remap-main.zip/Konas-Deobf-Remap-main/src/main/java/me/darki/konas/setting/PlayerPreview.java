package me.darki.konas.setting;

public class PlayerPreview {
    public boolean Field1226;
    public boolean Field1227;

    public boolean Method1208() {
        return this.Field1226;
    }

    public boolean Method1209() {
        return this.Field1227;
    }

    public PlayerPreview(boolean bl, boolean bl2) {
        this.Field1226 = bl;
        this.Field1227 = bl2;
    }
}