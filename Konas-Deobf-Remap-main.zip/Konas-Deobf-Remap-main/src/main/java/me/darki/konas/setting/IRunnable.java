package me.darki.konas.setting;
// this is taken from Class529 should of probably stated that before
public interface IRunnable<T> {
    void run(T argument);
}