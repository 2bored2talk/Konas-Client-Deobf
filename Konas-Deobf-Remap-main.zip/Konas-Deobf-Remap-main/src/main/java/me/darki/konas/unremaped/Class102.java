package me.darki.konas.unremaped;

import me.darki.konas.*;
import me.darki.konas.event.CancelableEvent;

public class Class102
extends CancelableEvent {
    public float Field2625 = 1.0f;
    public float Field2626 = 1.0f;
    public float Field2627 = 1.0f;
    public float Field2628 = 1.0f;

    public void Method294(float f) {
        this.Field2628 = f;
    }

    public float Method213() {
        return this.Field2628;
    }

    public float Method214() {
        return this.Field2627;
    }

    public void Method344(float f) {
        this.Field2626 = f;
    }

    public float Method215() {
        return this.Field2626;
    }

    public void Method1102(float f) {
        this.Field2627 = f;
    }

    public float Method1108() {
        return this.Field2625;
    }

    public void Method341(float f) {
        this.Field2625 = f;
    }
}