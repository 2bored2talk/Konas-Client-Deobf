package me.darki.konas.unremaped;

import me.darki.konas.*;
public class Class118 {
    public static int[] Field2446 = new int[Class144.Method1844().length];

    static {
        try {
            Class118.Field2446[Class144.TEXT.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class118.Field2446[Class144.IMAGE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}