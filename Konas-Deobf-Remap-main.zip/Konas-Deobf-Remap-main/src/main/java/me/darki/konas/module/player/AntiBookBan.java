package me.darki.konas.module.player;

import me.darki.konas.module.Category;
import me.darki.konas.module.Module;

public class AntiBookBan
extends Module {
    public AntiBookBan() {
        super("AntiBookBan", "Prevents you from getting book banned but can cause inventory desync", Category.PLAYER);
    }
}