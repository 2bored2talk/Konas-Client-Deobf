package me.darki.konas.unremaped;

import me.darki.konas.*;
public class Class3
extends Class20 {
    public Class3(double d) {
        super(d);
    }
}