package me.darki.konas.event.events;

import me.darki.konas.unremaped.Class22;
import net.minecraft.network.Packet;

public class PacketEvent
extends Class22 {
    public PacketEvent(Packet packet) {
        super(packet);
    }
}
