package me.darki.konas.unremaped;

import me.darki.konas.*;
public class Class314 {
    public static int[] Field761 = new int[Class323.Method743().length];

    static {
        try {
            Class314.Field761[Class323.PACKET.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class314.Field761[Class323.BYPASS.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class314.Field761[Class323.JUMP.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class314.Field761[Class323.SMALLJUMP.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}