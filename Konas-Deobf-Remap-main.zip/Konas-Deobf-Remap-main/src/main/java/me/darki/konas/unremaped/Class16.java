package me.darki.konas.unremaped;

import me.darki.konas.*;
import java.util.UUID;

public class Class16
extends Class29 {
    public Class16(String string, UUID uUID) {
        super(string, uUID);
    }
}