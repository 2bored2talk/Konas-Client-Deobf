package me.darki.konas.unremaped;

import me.darki.konas.*;
public class Class199 {
    public static int[] Field47 = new int[Class197.Method99().length];

    static {
        try {
            Class199.Field47[Class197.CUSTOM.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class199.Field47[Class197.LOGOUT.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class199.Field47[Class197.DEATH.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}