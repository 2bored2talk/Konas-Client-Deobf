package me.darki.konas.unremaped;

import me.darki.konas.*;
public class Class301 {
    public String Field1063;
    public String Field1064;

    public void Method1070(String string) {
        this.Field1064 = string;
    }

    public void Method1071(String string) {
        this.Field1063 = string;
    }

    public String Method1072() {
        return this.Field1063;
    }

    public Class301(String string, String string2) {
        this.Field1063 = string;
        this.Field1064 = string2;
    }

    public String Method1073() {
        return this.Field1064;
    }
}