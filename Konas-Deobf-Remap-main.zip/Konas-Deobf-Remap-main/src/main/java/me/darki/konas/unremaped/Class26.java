package me.darki.konas.unremaped;

import me.darki.konas.*;
import me.darki.konas.event.CancelableEvent;

public class Class26
extends CancelableEvent {
    public static Class26 Field139 = new Class26();

    public static Class26 Method219() {
        Field139.setCanceled(false);
        return Field139;
    }
}