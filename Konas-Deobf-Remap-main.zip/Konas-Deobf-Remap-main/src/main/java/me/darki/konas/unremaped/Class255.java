package me.darki.konas.unremaped;

import me.darki.konas.*;
import java.awt.Color;

public interface Class255 {
    public Color Method1920(Class244 var1, float var2, float var3);
}