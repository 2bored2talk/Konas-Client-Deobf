package me.darki.konas.unremaped;

import me.darki.konas.*;
import java.util.HashMap;

public class Class175
extends HashMap {
    public Notify Field1465;

    public Class175(Notify notify) {
        this.Field1465 = notify;
        this.put(20700000L, false);
        this.put(21000000L, false);
        this.put(21300000L, false);
        this.put(21540000L, false);
        this.put(21570000L, false);
    }
}