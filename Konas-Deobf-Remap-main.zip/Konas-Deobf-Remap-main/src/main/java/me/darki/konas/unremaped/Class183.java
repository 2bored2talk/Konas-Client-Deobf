package me.darki.konas.unremaped;

import me.darki.konas.*;
public abstract class Class183 {
    public String Field1423;
    public float Field1424;
    public float Field1425;
    public float Field1426;
    public float Field1427;
    public float Field1428;
    public float Field1429;
    public float Field1430;
    public float Field1431;
    public float Field1432;
    public float Field1433;
    public boolean Field1434;
    public boolean Field1435;

    public float Method1470() {
        return this.Field1429;
    }

    public void Method1471(float f) {
        this.Field1431 = f;
    }

    public void Method1472(float f) {
        this.Field1429 = f;
    }

    public boolean Method106(int n, int n2, int n3) {
        return false;
    }

    public float Method1473() {
        return this.Field1428;
    }

    public void Method102(char c, int n) {
    }

    public Class183(String string, float f, float f2, float f3, float f4, float f5, float f6) {
        this.Field1423 = string;
        this.Field1424 = f;
        this.Field1425 = f2;
        this.Field1428 = f3;
        this.Field1429 = f4;
        this.Field1430 = f + f3;
        this.Field1431 = f2 + f4;
        this.Field1432 = f5;
        this.Field1433 = f6;
    }

    public void Method1474(float f) {
        this.Field1424 = f;
    }

    public float Method1475() {
        return this.Field1430;
    }

    public float Method1476() {
        return this.Field1431;
    }

    public float Method1477() {
        return this.Field1427;
    }

    public void Method1478(float f) {
        this.Field1427 = f;
    }

    public void Method647(int n, int n2, int n3) {
    }

    public float Method1479() {
        return this.Field1432;
    }

    public void Method105(int n, int n2, float f) {
    }

    public String Method1480() {
        return this.Field1423;
    }

    public float Method1481() {
        return this.Field1433;
    }

    public float Method1482() {
        return this.Field1426;
    }

    public void Method649(int n, int n2, int n3, long l) {
    }

    public void Method1483(boolean bl) {
        this.Field1435 = bl;
    }

    public void Method1484(float f) {
        this.Field1428 = f;
    }

    public void Method1485(float f) {
        this.Field1425 = f;
    }

    public boolean Method1486() {
        return this.Field1435;
    }

    public boolean Method1487() {
        return this.Field1434;
    }

    public float Method1488() {
        return this.Field1424;
    }

    public void Method667() {
    }

    public float Method1489() {
        return this.Field1425;
    }

    public void Method1490(float f) {
        this.Field1426 = f;
    }

    public void Method665(float f, float f2) {
        this.Method1474(f);
        this.Method1485(f2);
        this.Method1491(this.Method1488() + this.Method1473());
        this.Method1471(this.Method1489() + this.Method1470());
    }

    public void Method1491(float f) {
        this.Field1430 = f;
    }

    public void Method1492(boolean bl) {
        this.Field1434 = bl;
    }

    public static boolean Method1493(int n, int n2, double d, double d2, double d3, double d4) {
        return (double)n >= d && (double)n <= d + d3 && (double)n2 >= d2 && (double)n2 <= d2 + d4;
    }
}
