package me.darki.konas.unremaped;

import me.darki.konas.*;
import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.Entity;

public class Class122
extends Class126 {
    public Class122(ModelBase modelBase, Entity entity, float f, float f2, float f3, float f4, float f5, float f6) {
        super(modelBase, entity, f, f2, f3, f4, f5, f6);
    }
}