package me.darki.konas.unremaped;

import me.darki.konas.*;
import me.darki.konas.event.CancelableEvent;

public class Class20
extends CancelableEvent {
    public double Field136;

    public Class20(double d) {
        this.Field136 = d;
    }

    public double Method216() {
        return this.Field136;
    }

    public void Method89(double d) {
        this.Field136 = d;
    }
}