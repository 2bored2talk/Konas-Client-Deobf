package me.darki.konas.unremaped;

import me.darki.konas.*;
public class Class10
extends Class9 {
}