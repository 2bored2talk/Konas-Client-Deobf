package me.darki.konas.gui.clickgui.unremappedGuiStuff;

import me.darki.konas.*;
public abstract class guiFrameDuplicatePossiblyForAimwareGui {
    public String Field852;
    public float Field853;
    public float Field854;
    public float Field855;
    public float Field856;
    public float Field857;
    public float Field858;
    public boolean Field859;
    public boolean Field860;

    public void Method445(float f) {
        this.Field853 = f;
    }

    public void Method712() {
    }

    public void Method704(int n, int n2, int n3, long l) {
    }

    public void Method709(float f, float f2) {
    }

    public float Method910() {
        return this.Field857;
    }

    public float Method911() {
        return this.Field858;
    }

    public void Method713(char c, int n) {
    }

    public void Method912(float f) {
        this.Field856 = f;
    }

    public boolean Method100(int n, int n2, int n3) {
        return false;
    }

    public float Method913() {
        return this.Field855;
    }

    public boolean Method914() {
        return this.Field860;
    }

    public void Method441(boolean bl) {
        this.Field859 = bl;
    }

    public float Method915() {
        return this.Field856;
    }

    public static boolean Method916(int n, int n2, double d, double d2, double d3, double d4) {
        return (double)n >= d && (double)n <= d + d3 && (double)n2 >= d2 && (double)n2 <= d2 + d4;
    }

    public void Method440(boolean bl) {
        this.Field860 = bl;
    }

    public boolean Method917() {
        return this.Field859;
    }

    public void Method918(float f) {
        this.Field857 = f;
    }

    public void Method444(int n, int n2, int n3) {
    }

    public void Method919(float f) {
        this.Field858 = f;
    }

    public String Method920() {
        return this.Field852;
    }

    public float Method921() {
        return this.Field854;
    }

    public void Method442(float f) {
        this.Field854 = f;
    }

    public void Method101(int n, int n2, float f) {
    }

    public float Method922() {
        return this.Field853;
    }

    public void Method923(float f) {
        this.Field855 = f;
    }

    public guiFrameDuplicatePossiblyForAimwareGui(String string, float f, float f2, float f3, float f4) {
        this.Field852 = string;
        this.Field853 = f;
        this.Field854 = f2;
        this.Field857 = f3;
        this.Field858 = f4;
    }
}
