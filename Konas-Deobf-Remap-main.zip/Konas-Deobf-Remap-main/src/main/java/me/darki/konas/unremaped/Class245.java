package me.darki.konas.unremaped;

import me.darki.konas.*;
public class Class245 {
    public static int[] Field2222 = new int[Class268.Method1830().length];

    static {
        try {
            Class245.Field2222[Class268.PACKET.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class245.Field2222[Class268.TP.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class245.Field2222[Class268.ANTI.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class245.Field2222[Class268.VANILLA.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}