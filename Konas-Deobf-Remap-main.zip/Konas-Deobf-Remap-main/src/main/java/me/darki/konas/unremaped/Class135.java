package me.darki.konas.unremaped;

import me.darki.konas.*;
public interface Class135 {
    public void Method485(float var1, float var2);

    public void Method497(int var1, int var2, float var3);

    public void Method477(int var1, int var2, float var3);

    public void Method481(int var1, int var2, int var3);

    public boolean Method494(int var1, int var2, int var3);

    public boolean Method491(int var1, int var2, int var3, long var4);

    public void Method479(char var1, int var2);
}