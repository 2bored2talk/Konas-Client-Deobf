package me.darki.konas.unremaped;

import me.darki.konas.*;
public class Class133 {
    public String Field2148;

    public String Method1953() {
        return this.Field2148;
    }

    public void Method1954(String string) {
        this.Field2148 = string;
    }

    public Class133(String string) {
        this.Field2148 = string;
    }
}