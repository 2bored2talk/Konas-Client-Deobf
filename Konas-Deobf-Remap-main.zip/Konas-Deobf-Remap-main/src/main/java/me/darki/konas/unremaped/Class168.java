package me.darki.konas.unremaped;

import me.darki.konas.*;
import me.darki.konas.module.client.KonasGlobals;

public class Class168
extends Thread {
    public Class166 Field1688;

    public Class168(Class166 class166, Class156 class156) {
        this(class166);
    }

    public Class168(Class166 class166) {
        this.Field1688 = class166;
    }

    @Override
    public void run() {
        KonasGlobals.INSTANCE.Field1132.Field1740.Method1668().Method1543();
    }
}