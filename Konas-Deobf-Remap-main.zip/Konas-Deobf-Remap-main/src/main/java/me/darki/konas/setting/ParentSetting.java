package me.darki.konas.setting;

public class ParentSetting {
    public boolean Field1247;

    public boolean Method1230() {
        return this.Field1247;
    }

    public ParentSetting(boolean bl) {
        this.Field1247 = bl;
    }

    public void Method1231(boolean bl) {
        this.Field1247 = bl;
    }
}