package me.darki.konas.unremaped;

import me.darki.konas.*;
import net.minecraft.item.ItemStack;

public class Class136 {
    public ItemStack Field2071;
    public int Field2072;
    public int Field2073;

    public ItemStack Method1926() {
        return this.Field2071;
    }

    public Class136(ItemStack itemStack, int n, int n2) {
        this.Field2071 = itemStack;
        this.Field2072 = n;
        this.Field2073 = n2;
    }

    public int Method1927() {
        return this.Field2073;
    }

    public int Method1928() {
        return this.Field2072;
    }
}