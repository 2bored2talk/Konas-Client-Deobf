package me.darki.konas.unremaped;

import me.darki.konas.*;
import net.minecraft.entity.Entity;

public class Class100
extends Class124 {
    public Class100(Entity entity, double d, double d2, double d3, float f, float f2) {
        super(entity, d, d2, d3, f, f2);
    }
}