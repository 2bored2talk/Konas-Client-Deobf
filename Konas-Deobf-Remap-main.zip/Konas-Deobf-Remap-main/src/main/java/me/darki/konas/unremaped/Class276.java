package me.darki.konas.unremaped;

import me.darki.konas.*;
import net.minecraft.util.math.BlockPos;

public class Class276 {
    public static BlockPos[] Field1873 = new BlockPos[]{new BlockPos(0, 1, 0), new BlockPos(0, 2, 0)};
    public static BlockPos[] Field1874 = new BlockPos[]{new BlockPos(-1, 2, 0), new BlockPos(1, 2, 0)};
    public static BlockPos[] Field1875 = new BlockPos[]{new BlockPos(0, 2, -1), new BlockPos(0, 2, 1)};
    public static BlockPos[] Field1876 = new BlockPos[]{new BlockPos(0, 3, 0), new BlockPos(-1, 3, 0), new BlockPos(1, 3, 0)};
    public static BlockPos[] Field1877 = new BlockPos[]{new BlockPos(0, 3, 0), new BlockPos(0, 3, -1), new BlockPos(0, 3, 1)};
    public static BlockPos[] Field1878 = new BlockPos[]{new BlockPos(0, 3, 0)};

    public static BlockPos[] Method1765() {
        return Field1873;
    }

    public static BlockPos[] Method1766() {
        return Field1874;
    }

    public static BlockPos[] Method1767() {
        return Field1875;
    }

    public static BlockPos[] Method1768() {
        return Field1877;
    }

    public static BlockPos[] Method1769() {
        return Field1876;
    }
}