package me.darki.konas.unremaped;

import me.darki.konas.*;
import java.awt.Color;

public class Class238
implements Class255 {
    public Color Field2395;

    @Override
    public Color Method1920(Class244 class244, float f, float f2) {
        return this.Field2395;
    }

    public Class238(Color color) {
        this.Field2395 = color;
    }
}