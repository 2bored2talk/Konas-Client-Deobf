package me.darki.konas.unremaped;

import me.darki.konas.*;
public class Class227 {
    public static int[] Field2571 = new int[Class254.Method1956().length];

    static {
        try {
            Class227.Field2571[Class254.VANILLA.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class227.Field2571[Class254.SPIGOT.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}