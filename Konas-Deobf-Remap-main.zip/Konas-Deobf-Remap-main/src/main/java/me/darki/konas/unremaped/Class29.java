package me.darki.konas.unremaped;

import me.darki.konas.*;
import java.util.UUID;

public class Class29 {
    public String Field131;
    public UUID Field132;

    public Class29(String string, UUID uUID) {
        this.Field131 = string;
        this.Field132 = uUID;
    }

    public UUID Method209() {
        return this.Field132;
    }

    public void Method210(String string) {
        this.Field131 = string;
    }

    public String Method211() {
        return this.Field131;
    }

    public void Method212(UUID uUID) {
        this.Field132 = uUID;
    }
}